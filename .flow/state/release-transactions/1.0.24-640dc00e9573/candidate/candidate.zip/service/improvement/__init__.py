"""Canonical improvement-domain models."""
